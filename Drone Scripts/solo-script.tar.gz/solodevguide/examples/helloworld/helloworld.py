from dronekit import connect
import sys

# Connect to UDP endpoint (and wait for default attributes to accumulate)
target = sys.argv[1] if len(sys.argv) >= 2 else 'udpin:0.0.0.0:14550'
print 'Connecting to ' + target + '...'
vehicle = connect(target, wait_ready=True)

# Get all vehicle attributes (state)
while True:
    print " Global Location (relative altitude): %s" % vehicle.location.global_relative_frame

vehicle.close()
print "Done."
