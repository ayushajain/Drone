import sys
sys.path.append("/usr/lib/python2.7/site-packages")
import cv2
import time
import threading
from SoloCamera import SoloCamera

cam = SoloCamera()
if cam.isOpened():
    print "Capturing an image..."
    ret, frame = cam.read()
    if frame is None:
        print "No image"
    else:
        cv2.imwrite("test.png", frame)
else:
    print "failed to open gopro"

print "closing camera..."
