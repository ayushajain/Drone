from firebase import firebase
firebase = firebase.FirebaseApplication('https://solodata.firebaseio.com/', None)


result = firebase.post('/', "bruh", {'print': 'pretty'}, {'X_FANCY_HEADER': 'VERY FANCY'})
print result
