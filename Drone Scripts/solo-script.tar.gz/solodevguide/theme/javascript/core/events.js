define([
    "jQuery"
], function($) {
   var events = $({});

    return events;
});