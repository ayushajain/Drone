# Skywriter

Move solo around using high-level directional commands.

**NOTE:** To run this example, please `git clone` or download all the files in the [skywriter folder](https://github.com/3drobotics/solodevguide/tree/master/examples/skywriter) on Github.

## High-level directional commands

DroneDirect is a library that exposes several high-level methods:

...

## TODO

This
