Python API for communication and control of drones over MAVLink.


